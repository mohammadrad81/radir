# radir
an IR system project
